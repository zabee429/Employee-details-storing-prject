import React, { createContext, useState } from "react";

export const LeadsContext = createContext();

const LeadsProvider = ({ children }) => {
    const [leads, setLeads] = useState([
            { id: 1, name: "John Doe", status: "New", source: "Facebook", date: "2024-12-10", email: "johndoe@example.com", phone: "+1 555-1234" },
            { id: 2, name: "Jane Smith", status: "Contacted", source: "Google", date: "2024-12-11", email: "janesmith@example.com", phone: "+1 555-5678" },
            { id: 3, name: "Robert Brown", status: "Not Interested", source: "Twitter", date: "2024-12-12", email: "robertbrown@example.com", phone: "+1 555-9101" },
            { id: 4, name: "Alice White", status: "New", source: "Website", date: "2024-12-13", email: "alicewhite@example.com", phone: "+1 555-1122" },
            { id: 5, name: "Michael Green", status: "Contacted", source: "Offline Event", date: "2024-12-14", email: "michaelgreen@example.com", phone: "+1 555-3344" },
            { id: 6, name: "Liam Johnson", status: "New", source: "Facebook", date: "2024-12-15", email: "liamjohnson@example.com", phone: "+1 555-7788" },
            { id: 7, name: "Emma Williams", status: "Contacted", source: "Google", date: "2024-12-16", email: "emmawilliams@example.com", phone: "+1 555-5566" },
            { id: 8, name: "Olivia Jones", status: "Not Interested", source: "Twitter", date: "2024-12-17", email: "oliviajones@example.com", phone: "+1 555-3344" },
            { id: 9, name: "Sophia Brown", status: "New", source: "Website", date: "2024-12-18", email: "sophiabrown@example.com", phone: "+1 555-8877" },
            { id: 10, name: "Mason Taylor", status: "Contacted", source: "Offline Event", date: "2024-12-19", email: "masontaylor@example.com", phone: "+1 555-9988" },
            { id: 11, name: "Isabella Moore", status: "Not Interested", source: "Facebook", date: "2024-12-20", email: "isabellamoore@example.com", phone: "+1 555-2244" },
            { id: 12, name: "Lucas Anderson", status: "New", source: "Google", date: "2024-12-21", email: "lucasanderson@example.com", phone: "+1 555-4455" },
            { id: 13, name: "Mia Thomas", status: "Contacted", source: "Twitter", date: "2024-12-22", email: "miathomas@example.com", phone: "+1 555-7788" },
            { id: 14, name: "Ethan Jackson", status: "Not Interested", source: "Website", date: "2024-12-23", email: "ethanjackson@example.com", phone: "+1 555-6677" },
            { id: 15, name: "Avery White", status: "New", source: "Offline Event", date: "2024-12-24", email: "averywhite@example.com", phone: "+1 555-9988" },
            { id: 16, name: "Jack Harris", status: "Contacted", source: "Facebook", date: "2024-12-25", email: "jackharris@example.com", phone: "+1 555-1122" },
            { id: 17, name: "Chloe Clark", status: "Not Interested", source: "Google", date: "2024-12-26", email: "chloeclark@example.com", phone: "+1 555-4433" },
            { id: 18, name: "Benjamin Lewis", status: "New", source: "Twitter", date: "2024-12-27", email: "benjaminlewis@example.com", phone: "+1 555-5566" },
            { id: 19, name: "Charlotte Young", status: "Contacted", source: "Website", date: "2024-12-28", email: "charlotteyoung@example.com", phone: "+1 555-8899" },
            { id: 20, name: "James King", status: "Not Interested", source: "Offline Event", date: "2024-12-29", email: "jamesking@example.com", phone: "+1 555-6677" }
        
    ]);

    const addLead = (lead) => setLeads([...leads, lead]);

    const updateLead = (updatedLead) => {
        setLeads(leads.map((lead) => (lead.id === updatedLead.id ? updatedLead : lead)));
    };
    const updateLeadStatus = (id, newStatus) => {
        setLeads((prevLeads) =>
            prevLeads.map((lead) =>
                lead.id === id ? { ...lead, status: newStatus } : lead
            )
        );
    };
    

    return (

        <LeadsContext.Provider value={{ leads, addLead, updateLead , updateLeadStatus  }}>
            {children}
        </LeadsContext.Provider>
    );
};

export default LeadsProvider;
