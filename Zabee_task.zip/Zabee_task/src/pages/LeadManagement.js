import React, { useContext, useState } from "react";
import { LeadsContext } from "../context/LeadsContext";
import { Link } from "react-router-dom";

const LeadManagement = () => {
    const { leads, updateLeadStatus } = useContext(LeadsContext);

    // Filter leads by status
    const [selectedStatus, setSelectedStatus] = useState("All");

    const filteredLeads = selectedStatus === "All" 
        ? leads 
        : leads.filter(lead => lead.status === selectedStatus);

    // Handle status update
    const handleStatusChange = (id, newStatus) => {
        updateLeadStatus(id, newStatus);
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Lead Management</h1>

            {/* Filter by Status */}
            <div className="row mb-3">
                <div className="col-md-6 offset-md-3">
                    <select
                        className="form-select"
                        value={selectedStatus}
                        onChange={(e) => setSelectedStatus(e.target.value)}
                    >
                        <option value="All">All Statuses</option>
                        <option value="New">New</option>
                        <option value="Contacted">Contacted</option>
                        <option value="Not Interested">Not Interested</option>
                    </select>
                </div>
            </div>

            {/* Lead Management Table */}
            <table className="table table-striped table-hover">
                <thead className="thead-dark">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredLeads.map((lead, index) => (
                        <tr key={lead.id}>
                            <td>{index + 1}</td>
                            <td>{lead.name}</td>
                            <td>{lead.email}</td>
                            <td>{lead.phone}</td>
                            <td>
                                <span
                                    className={`badge ${
                                        lead.status === "New"
                                            ? "bg-success"
                                            : lead.status === "Contacted"
                                            ? "bg-warning"
                                            : "bg-danger"
                                    }`}
                                >
                                    {lead.status}
                                </span>
                            </td>
                            <td>
                                <Link to={`/leaddetails/${lead.id}`} className="btn btn-info me-2">
                                    View Details
                                </Link>
                                <select
                                    className="form-select"
                                    value={lead.status}
                                    onChange={(e) =>
                                        handleStatusChange(lead.id, e.target.value)
                                    }
                                >
                                    <option value="New">New</option>
                                    <option value="Contacted">Contacted</option>
                                    <option value="Not Interested">Not Interested</option>
                                </select>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default LeadManagement;
