import React, { useContext } from "react";
import { LeadsContext } from "../context/LeadsContext";
import {
    PieChart,
    Pie,
    Tooltip,
    Cell,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Legend,
} from "recharts";

const Dashboard = () => {
    const { leads } = useContext(LeadsContext);

    // Calculate lead counts by status
    const statusData = leads.reduce((counts, lead) => {
        counts[lead.status] = (counts[lead.status] || 0) + 1;
        return counts;
    }, {});

    // Prepare data for Pie Chart
    const pieChartData = Object.entries(statusData).map(([status, count]) => ({
        name: status,
        value: count,
    }));

    // Prepare data for Bar Chart (Lead Sources)
    const sourceData = leads.reduce((counts, lead) => {
        counts[lead.source] = (counts[lead.source] || 0) + 1;
        return counts;
    }, {});

    const barChartData = Object.entries(sourceData).map(([source, count]) => ({
        name: source,
        value: count,
    }));

    // Colors for the Pie Chart
    const COLORS = ["#007bff", "#28a745", "#ffc107", "#dc3545"];

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Dashboard</h1>

            {/* Quick Stats Cards */}
            <div className="row text-center my-4">
                <div className="col-md-3">
                    <div className="card text-white bg-success mb-3">
                        <div className="card-body">
                            <h5 className="card-title">New Leads</h5>
                            <p className="card-text">{statusData["New"] || 0}</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card text-white bg-warning mb-3">
                        <div className="card-body">
                            <h5 className="card-title">Contacted</h5>
                            <p className="card-text">{statusData["Contacted"] || 0}</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card text-white bg-danger mb-3">
                        <div className="card-body">
                            <h5 className="card-title">Not Interested</h5>
                            <p className="card-text">{statusData["Not Interested"] || 0}</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-3">
                    <div className="card text-white bg-primary mb-3">
                        <div className="card-body">
                            <h5 className="card-title">Total Leads</h5>
                            <p className="card-text">{leads.length}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Charts Section */}
            <div className="row">
                {/* Pie Chart */}
                <div className="col-md-6">
                    <h2 className="text-center">Lead Status Distribution</h2>
                    <PieChart width={500} height={400}>
                        <Pie
                            data={pieChartData}
                            cx={200}
                            cy={200}
                            labelLine={false}
                            label={(entry) => `${entry.name}: ${entry.value}`}
                            outerRadius={150}
                            fill="#8884d8"
                            dataKey="value"
                        >
                            {pieChartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </div>

                {/* Bar Chart */}
                <div className="col-md-6">
                    <h2 className="text-center">Lead Sources</h2>
                    <BarChart width={500} height={300} data={barChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="value" fill="#17a2b8" />
                    </BarChart>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
