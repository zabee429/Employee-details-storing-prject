import React, { useContext, useEffect, useState } from "react";
import { LeadsContext } from "../context/LeadsContext";
import { useParams, useNavigate } from "react-router-dom";

const LeadDetails = () => {
    const { leads, updateLeadStatus } = useContext(LeadsContext);
    const { leadId } = useParams();
    const navigate = useNavigate(); // Use useNavigate hook
    
    const [lead, setLead] = useState(null);

    useEffect(() => {
        const foundLead = leads.find((l) => l.id === parseInt(leadId));
        setLead(foundLead);
    }, [leadId, leads]);

    if (!lead) {
        console.log(leadId)
        return <div>Loading...</div>;
    }

    // Handle status update
    const handleStatusChange = (newStatus) => {
        updateLeadStatus(lead.id, newStatus);
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Lead Details</h1>
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">{lead.name}</h5>
                            <p className="card-text">
                                <strong>Email:</strong> {lead.email}
                            </p>
                            <p className="card-text">
                                <strong>Phone:</strong> {lead.phone}
                            </p>
                            <p className="card-text">
                                <strong>Source:</strong> {lead.source}
                            </p>
                            <p className="card-text">
                                <strong>Status:</strong>{" "}
                                <span
                                    className={`badge ${
                                        lead.status === "New"
                                            ? "bg-success"
                                            : lead.status === "Contacted"
                                            ? "bg-warning"
                                            : "bg-danger"
                                    }`}
                                >
                                    {lead.status}
                                </span>
                            </p>

                            <div className="mb-3">
                                <select
                                    className="form-select"
                                    value={lead.status}
                                    onChange={(e) => handleStatusChange(e.target.value)}
                                >
                                    <option value="New">New</option>
                                    <option value="Contacted">Contacted</option>
                                    <option value="Not Interested">Not Interested</option>
                                </select>
                            </div>

                            <button
                                className="btn btn-secondary"
                                onClick={() => navigate(-1)} // use navigate(-1) to go back
                            >
                                Go Back
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LeadDetails;
