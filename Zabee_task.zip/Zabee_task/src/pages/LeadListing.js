import React, { useState, useContext } from "react";
import { LeadsContext } from "../context/LeadsContext";
import { Link } from "react-router-dom";

const LeadListing = () => {
    const { leads, updateLeadStatus } = useContext(LeadsContext);

    // State for search and pagination
    const [searchTerm, setSearchTerm] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const leadsPerPage = 5;

    // Filter leads based on search term
    const filteredLeads = leads.filter((lead) =>
        lead.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Pagination logic
    const indexOfLastLead = currentPage * leadsPerPage;
    const indexOfFirstLead = indexOfLastLead - leadsPerPage;
    const currentLeads = filteredLeads.slice(indexOfFirstLead, indexOfLastLead);

    const totalPages = Math.ceil(filteredLeads.length / leadsPerPage);

    // Handle status update
    const handleStatusChange = (id, newStatus) => {
        updateLeadStatus(id, newStatus);
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">
        Lead Listing
        {/* Adding links to Dashboard and Lead Management */}
        <div className="mt-3">
          <Link to="/dashboard" className="btn btn-primary mr-3">
            Go to Dashboard
          </Link>
          <Link to="/manage-leads" className="btn btn-secondary">
            Lead Management
          </Link>
        </div>
      </h1>

            {/* Search Bar */}
            <div className="row mb-3">
                <div className="col-md-6 offset-md-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search by name"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* Leads Table */}
            <table className="table table-striped table-hover">
                <thead className="thead-dark">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Source</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentLeads.map((lead, index) => (
                        <tr key={lead.id}>
                            <td>{indexOfFirstLead + index + 1}</td>
                            <td>{lead.name}</td>
                            <td>{lead.email}</td>
                            <td>{lead.phone}</td>
                            <td>{lead.source}</td>
                            <td>
                                <span
                                    className={`badge ${
                                        lead.status === "New"
                                            ? "bg-success"
                                            : lead.status === "Contacted"
                                            ? "bg-warning"
                                            : "bg-danger"
                                    }`}
                                >
                                    {lead.status}
                                </span>
                            </td>
                            <td>
                                <Link to={`/leads/${lead.id}`} className="btn btn-info">
                                    View Details
                                </Link>
                            </td>

                            <td>
                                <select
                                    className="form-select"
                                    value={lead.status}
                                    onChange={(e) =>
                                        handleStatusChange(lead.id, e.target.value)
                                    }
                                >
                                    <option value="New">New</option>
                                    <option value="Contacted">Contacted</option>
                                    <option value="Not Interested">Not Interested</option>
                                </select>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Pagination */}
            <nav>
                <ul className="pagination justify-content-center">
                    {[...Array(totalPages)].map((_, page) => (
                        <li
                            key={page}
                            className={`page-item ${
                                currentPage === page + 1 ? "active" : ""
                            }`}
                        >
                            <button
                                className="page-link"
                                onClick={() => setCurrentPage(page + 1)}
                            >
                                {page + 1}
                            </button>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    );
};

export default LeadListing;
